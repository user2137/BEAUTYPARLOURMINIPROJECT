from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import sqlite3
from datetime import date
import os

app = Flask(__name__)
app.secret_key = "premium_beauty_secret"
DATABASE = 'beauty_parlour.db'

@app.context_processor
def inject_date():
    return dict(date=date)

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # SQL for SQLite - create tables
    cursor.executescript('''
    CREATE TABLE IF NOT EXISTS customer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS service (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        service_name TEXT NOT NULL,
        price REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS product (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_name TEXT NOT NULL,
        brand TEXT NOT NULL,
        stock INTEGER DEFAULT 0,
        price REAL NOT NULL,
        category TEXT DEFAULT 'General',
        icon TEXT DEFAULT '💄',
        bg_color TEXT DEFAULT '#fce4ec'
    );

    CREATE TABLE IF NOT EXISTS appointment (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        service_id INTEGER,
        date TEXT,
        time TEXT,
        status TEXT DEFAULT 'Pending',
        FOREIGN KEY (customer_id) REFERENCES customer(id),
        FOREIGN KEY (service_id) REFERENCES service(id)
    );

    CREATE TABLE IF NOT EXISTS bill (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        appointment_id INTEGER,
        total_amount REAL,
        bill_date TEXT,
        FOREIGN KEY (customer_id) REFERENCES customer(id),
        FOREIGN KEY (appointment_id) REFERENCES appointment(id)
    );

    CREATE TABLE IF NOT EXISTS bill_item (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER,
        item_name TEXT,
        item_type TEXT,
        quantity INTEGER DEFAULT 1,
        price REAL,
        FOREIGN KEY (bill_id) REFERENCES bill(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER,
        subject TEXT,
        message TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (customer_id) REFERENCES customer(id)
    );
    ''')
    
    # Ensure new columns exist in bill table if it already existed
    try:
        cursor.execute("ALTER TABLE bill ADD COLUMN appointment_id INTEGER")
    except: pass
    
    # Ensure new columns exist in product table if it already existed
    try:
        cursor.execute("ALTER TABLE product ADD COLUMN category TEXT DEFAULT 'General'")
    except: pass
    try:
        cursor.execute("ALTER TABLE product ADD COLUMN icon TEXT DEFAULT '💄'")
    except: pass
    try:
        cursor.execute("ALTER TABLE product ADD COLUMN bg_color TEXT DEFAULT '#fce4ec'")
    except: pass
    
    # Seed Services
    cursor.execute("SELECT COUNT(*) FROM service")
    if cursor.fetchone()[0] == 0:
        services = [
            ("Classic Haircut", 500.0),
            ("Luxury Facial", 1200.0),
            ("Bridal Makeup", 5000.0),
            ("Hair Coloring", 1500.0),
            ("Manicure & Pedicure", 800.0),
        ]
        cursor.executemany("INSERT INTO service (service_name, price) VALUES (?, ?)", services)

    # Seed Products (product_name, brand, stock, price, category, icon, bg_color)
    cursor.execute("SELECT COUNT(*) FROM product")
    if cursor.fetchone()[0] == 0:
        dummy_products = [
            ("Matte Lipstick",        "Lakme",      50,  450.0,  "Makeup",    "💄", "#fce4ec"),
            ("Waterproof Foundation", "Maybelline",  20,  850.0,  "Makeup",    "🧴", "#fff3e0"),
            ("Gel Eyeliner",          "Revlon",      35,  400.0,  "Makeup",    "✏️", "#ede7f6"),
            ("Compact Powder",        "Lakme",       45,  380.0,  "Makeup",    "🪞", "#f3e5f5"),
            ("Kajal (Kohl)",          "Himalaya",    80,  150.0,  "Makeup",    "👁️", "#e8eaf6"),
            ("Hydrating Moisturizer", "Neutrogena",  30,  600.0,  "Skincare",  "🧼", "#e0f7fa"),
            ("Sunscreen SPF 50",      "La Shield",   25,  750.0,  "Skincare",  "☀️", "#fff8e1"),
            ("Anti-Aging Cream",      "Olay",        15, 1200.0,  "Skincare",  "🌿", "#e8f5e9"),
            ("Hair Repair Serum",     "L'Oreal",     40,  550.0,  "Hair",      "💇", "#f9fbe7"),
            ("Luxury Perfume",        "Chanel",      10, 8500.0,  "Fragrance", "🌸", "#fce4ec"),
        ]
        cursor.executemany(
            "INSERT INTO product (product_name, brand, stock, price, category, icon, bg_color) VALUES (?, ?, ?, ?, ?, ?, ?)",
            dummy_products
        )

    conn.commit()
    conn.close()

# Initialize DB on start
init_db()

# --- USER ROUTES ---

@app.route("/")
def index():
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM service LIMIT 6")
        services = [dict(row) for row in cursor.fetchall()]
        cursor.execute("SELECT * FROM product WHERE stock > 0 LIMIT 6")
        products = [dict(row) for row in cursor.fetchall()]
        conn.close()
    except:
        services = []
        products = []
    return render_template("user_home.html", services=services, products=products)

@app.route("/products_list")
def products_list():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM product")
    all_products = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("user_products.html", products=all_products)

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name")
        phone = request.form.get("phone")
        email = request.form.get("email")
        password = request.form.get("password")
        
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO customer (name, phone, email, password) VALUES (?, ?, ?, ?)", 
                           (name, phone, email, password))
            conn.commit()
            conn.close()
            flash("Account created! Please log in.", "success")
            return redirect(url_for("user_login"))
        except sqlite3.IntegrityError:
            flash("Error: Email address already registered.", "error")
        except Exception as e:
            flash(f"Error creating account: {e}", "error")
    return render_template("user_register.html")

@app.route("/login", methods=["GET", "POST"])
def user_login():
    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")
        
        # Check if it's the Admin logging in from the common login page
        if email == "admin@beauty" and password == "admin123":
            session["admin_logged"] = True
            flash("Welcome to Admin Dashboard!", "success")
            return redirect(url_for("dashboard"))
            
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM customer WHERE email = ? AND password = ?", (email, password))
            user = cursor.fetchone()
            conn.close()
            if user:
                session["user_logged_in"] = True
                session["user_id"] = user["id"]
                session["user_name"] = user["name"]
                flash(f"Welcome back, {user['name']}!", "success")
                return redirect(url_for("index"))
            else:
                flash("Invalid credentials!", "error")
        except Exception as e:
            flash(f"Error logging in: {e}", "error")
    return render_template("user_login.html")

@app.route("/logout")
def user_logout():
    session.pop("user_logged_in", None)
    session.pop("user_id", None)
    session.pop("user_name", None)
    flash("Logged out.", "success")
    return redirect(url_for("index"))

@app.route("/book_appointment", methods=["GET", "POST"])
def book_appointment():
    if not session.get("user_logged_in"):
        flash("Please log in to book an appointment.", "error")
        return redirect(url_for("user_login"))
        
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == "POST":
        service_id = request.form.get("service_id")
        apt_date = request.form.get("date")
        apt_time = request.form.get("time")
        
        try:
            cursor.execute("""
                INSERT INTO appointment (customer_id, service_id, date, time, status) 
                VALUES (?, ?, ?, ?, 'Pending')
            """, (session["user_id"], service_id, apt_date, apt_time))
            conn.commit()
            flash("Appointment requested successfully! Waiting for Admin approval.", "success")
            return redirect(url_for("my_bookings"))
        except Exception as e:
            flash(f"Error booking appointment: {e}", "error")

    cursor.execute("SELECT * FROM service")
    services = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("user_book.html", services=services)

@app.route("/my_bookings")
def my_bookings():
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
        
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.id, s.service_name, a.date, a.time, a.status, b.total_amount as bill_total, b.id as bill_id
        FROM appointment a
        JOIN service s ON a.service_id = s.id
        LEFT JOIN bill b ON b.appointment_id = a.id
        WHERE a.customer_id = ?
        ORDER BY a.date DESC, a.time DESC
    """, (session["user_id"],))
    bookings = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("user_bookings.html", bookings=bookings)

@app.route("/cancel_appointment/<int:apt_id>", methods=["POST"])
def cancel_appointment(apt_id):
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
        
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("UPDATE appointment SET status = 'Cancelled' WHERE id = ? AND customer_id = ?", 
                   (apt_id, session["user_id"]))
    conn.commit()
    conn.close()
    flash("Appointment cancelled.", "success")
    return redirect(url_for("my_bookings"))

@app.route("/payment/<int:apt_id>", methods=["GET", "POST"])
def user_payment(apt_id):
    if not session.get("user_logged_in"):
        return redirect(url_for("user_login"))
        
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Get appointment details - Check if bill exists for synchronized pricing
    cursor.execute("""
        SELECT a.*, s.service_name, 
               COALESCE(b.total_amount, s.price) as final_price
        FROM appointment a
        JOIN service s ON a.service_id = s.id
        LEFT JOIN bill b ON b.appointment_id = a.id
        WHERE a.id = ? AND a.customer_id = ?
    """, (apt_id, session["user_id"]))
    appointment = cursor.fetchone()
    
    if not appointment:
        conn.close()
        flash("Appointment not found.", "error")
        return redirect(url_for("my_bookings"))
        
    if request.method == "POST":
        method = request.form.get("method")
        
        # 1. Update appointment status
        cursor.execute("UPDATE appointment SET status = 'Paid' WHERE id = ?", (apt_id,))
        
        # 2. Check if a bill already exists for this appointment
        cursor.execute("SELECT id FROM bill WHERE appointment_id = ?", (apt_id,))
        existing_bill = cursor.fetchone()
        
        if not existing_bill:
            # Create a simple bill for the service
            cursor.execute("INSERT INTO bill (customer_id, appointment_id, total_amount, bill_date) VALUES (?, ?, ?, date('now'))", 
                           (session["user_id"], apt_id, appointment['final_price']))
            bill_id = cursor.lastrowid
            
            # Add the service as a bill item
            cursor.execute("INSERT INTO bill_item (bill_id, item_name, item_type, quantity, price) VALUES (?, ?, 'Service', 1, ?)", 
                           (bill_id, appointment['service_name'], appointment['final_price']))
        
        conn.commit()
        conn.close()
        flash(f"Payment of ₹{appointment['final_price']} successful! Invoice generated.", "success")
        return redirect(url_for("my_bookings"))
        
    conn.close()
    appointment_dict = dict(appointment)
    # Ensure templates can use .price if they expect it
    appointment_dict['price'] = appointment_dict['final_price']
    return render_template("user_payment.html", appointment=appointment_dict)

@app.route("/user/view_receipt/<int:apt_id>")
def view_receipt(apt_id):
    if not session.get("user_logged_in"): return redirect(url_for("user_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 1. Try to find a bill linked to this appointment
    cursor.execute("SELECT id FROM bill WHERE appointment_id = ?", (apt_id,))
    bill_row = cursor.fetchone()
    
    if bill_row:
        return redirect(url_for("user_view_invoice", bill_id=bill_row['id']))
    
    # 2. If no bill linked, find appointment info and create one (for old data)
    cursor.execute("""
        SELECT a.*, s.service_name, s.price 
        FROM appointment a JOIN service s ON a.service_id = s.id 
        WHERE a.id = ? AND a.customer_id = ? AND a.status = 'Paid'
    """, (apt_id, session["user_id"]))
    apt = cursor.fetchone()
    
    if not apt:
        conn.close()
        flash("Receipt not available.", "error")
        return redirect(url_for("my_bookings"))
        
    # Create the missing bill
    cursor.execute("INSERT INTO bill (customer_id, appointment_id, total_amount, bill_date) VALUES (?, ?, ?, ?)", 
                   (session["user_id"], apt_id, apt['price'], apt['date']))
    bill_id = cursor.lastrowid
    cursor.execute("INSERT INTO bill_item (bill_id, item_name, item_type, quantity, price) VALUES (?, ?, 'Service', 1, ?)", 
                   (bill_id, apt['service_name'], apt['price']))
    conn.commit()
    conn.close()
    
    return redirect(url_for("user_view_invoice", bill_id=bill_id))

@app.route("/user/view_invoice/<int:bill_id>")
def user_view_invoice(bill_id):
    if not session.get("user_logged_in"): return redirect(url_for("user_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT b.*, c.name as customer_name, c.phone FROM bill b JOIN customer c ON b.customer_id = c.id WHERE b.id = ? AND b.customer_id = ?", 
                   (bill_id, session["user_id"]))
    bill = cursor.fetchone()
    if not bill:
        conn.close()
        flash("Invoice not found.", "error")
        return redirect(url_for("my_bookings"))
    
    bill = dict(bill)
    cursor.execute("SELECT * FROM bill_item WHERE bill_id = ?", (bill_id,))
    items = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("view_bill.html", bill=bill, items=items, is_user=True)

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if not session.get("user_logged_in"):
        flash("Please log in to send feedback.", "error")
        return redirect(url_for("user_login"))
        
    if request.method == "POST":
        subject = request.form.get("subject")
        message = request.form.get("message")
        try:
            conn = get_db_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO feedback (customer_id, subject, message) VALUES (?, ?, ?)", 
                           (session["user_id"], subject, message))
            conn.commit()
            conn.close()
            flash("Thank you for your feedback!", "success")
        except Exception as e:
            flash("Error sending feedback.", "error")
        return redirect(url_for("index"))
        
    return render_template("user_contact.html")

# --- ADMIN ROUTES ---

def is_admin():
    return "admin_logged" in session

@app.route("/admin_login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        username = request.form.get("username")
        password = request.form.get("password")
        if username == "admin@beauty" and password == "admin123":
            session["admin_logged"] = True
            flash("Welcome to Admin Dashboard!", "success")
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid credentials!", "error")
    return render_template("login.html")

@app.route("/admin_logout")
def admin_logout():
    session.pop("admin_logged", None)
    flash("Logged out successfully.", "success")
    return redirect(url_for("admin_login"))

@app.route("/admin/dashboard")
def dashboard():
    if not is_admin():
        return redirect(url_for("admin_login"))
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT COUNT(*) as cnt FROM customer")
        customer_count = cursor.fetchone()["cnt"]
        
        cursor.execute("SELECT COUNT(*) as cnt FROM appointment")
        total_bookings = cursor.fetchone()["cnt"]
        
        cursor.execute("SELECT COUNT(*) as cnt FROM service")
        service_count = cursor.fetchone()["cnt"]
        
        cursor.execute("SELECT SUM(total_amount) as total FROM bill")
        total_revenue = cursor.fetchone()["total"] or 0
        
        cursor.execute("SELECT * FROM product WHERE stock <= 5")
        low_stock_products = [dict(row) for row in cursor.fetchall()]
        
        cursor.execute("""
            SELECT a.id, c.name, s.service_name, a.time, a.status 
            FROM appointment a
            JOIN customer c ON a.customer_id = c.id
            JOIN service s ON a.service_id = s.id
            WHERE a.date = date('now')
            ORDER BY a.time
        """)
        todays_apts = [dict(row) for row in cursor.fetchall()]
        
        conn.close()
    except Exception as e:
        customer_count = total_bookings = total_revenue = service_count = 0
        low_stock_products = todays_apts = []

    return render_template("dashboard.html", 
                           customer_count=customer_count, 
                           total_bookings=total_bookings,
                           service_count=service_count,
                           total_revenue=total_revenue,
                           low_stock_products=low_stock_products,
                           todays_apts=todays_apts,
                           date=date)

@app.route("/admin/customers", methods=["GET", "POST"])
def customers():
    if not is_admin():
        return redirect(url_for("admin_login"))
    
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == "POST":
        name = request.form.get("name")
        phone = request.form.get("phone")
        email = request.form.get("email")
        password = "changeme123" 
        try:
            cursor.execute("INSERT INTO customer (name, phone, email, password) VALUES (?, ?, ?, ?)", (name, phone, email, password))
            conn.commit()
            flash("User profile created!", "success")
            return redirect(url_for("customers"))
        except:
            flash("Error adding user (Email might exist)", "error")

    cursor.execute("SELECT * FROM customer ORDER BY id DESC")
    all_customers = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return render_template("view_customer.html", customers=all_customers)

@app.route("/admin/delete_customer/<int:c_id>", methods=["POST"])
def delete_customer(c_id):
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM customer WHERE id = ?", (c_id,))
        conn.commit()
        flash("User deleted successfully!", "success")
    except Exception as e:
        flash("Cannot delete user (they likely have linked bookings).", "error")
    conn.close()
    return redirect(url_for("customers"))

@app.route("/admin/services", methods=["GET", "POST"])
def services():
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == "POST":
        action = request.form.get("action")
        if action == "add":
            cursor.execute("INSERT INTO service (service_name, price) VALUES (?, ?)", (request.form.get("service_name"), request.form.get("price")))
            conn.commit()
            flash("Service catalog updated!", "success")
        elif action == "edit":
            cursor.execute("UPDATE service SET service_name=?, price=? WHERE id=?", (request.form.get("service_name"), request.form.get("price"), request.form.get("service_id")))
            conn.commit()
            flash("Service updated!", "success")
        return redirect(url_for("services"))
        
    cursor.execute("SELECT * FROM service ORDER BY id DESC")
    services_list = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("services.html", services=services_list)

@app.route("/admin/delete_service/<int:s_id>", methods=["POST"])
def delete_service(s_id):
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM service WHERE id = ?", (s_id,))
        conn.commit()
        flash("Service deleted!", "success")
    except Exception as e:
        flash("Cannot delete service as it is linked to appointments.", "error")
    conn.close()
    return redirect(url_for("services"))

@app.route("/admin/products", methods=["GET", "POST"])
def products():
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    if request.method == "POST":
        action = request.form.get("action", "add")
        product_name = request.form.get("product_name")
        brand = request.form.get("brand")
        category = request.form.get("category", "General")
        price = request.form.get("price")
        stock = request.form.get("stock")
        product_id = request.form.get("product_id")

        if action == "add":
            cursor.execute("INSERT INTO product (product_name, brand, category, stock, price) VALUES (?, ?, ?, ?, ?)", 
                           (product_name, brand, category, stock, price))
            conn.commit()
            flash("Product registered successfully!", "success")
        elif action == "edit" and product_id:
            cursor.execute("UPDATE product SET product_name=?, brand=?, category=?, stock=?, price=? WHERE id=?", 
                           (product_name, brand, category, stock, price, product_id))
            conn.commit()
            flash("Product updated successfully!", "success")
        return redirect(url_for("products"))

    cursor.execute("SELECT * FROM product ORDER BY stock ASC")
    products_list = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("products.html", products=products_list)

@app.route("/admin/delete_product/<int:p_id>", methods=["POST"])
def delete_product(p_id):
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM product WHERE id = ?", (p_id,))
        conn.commit()
        flash("Product deleted successfully!", "success")
    except Exception as e:
        flash("Cannot delete product.", "error")
    conn.close()
    return redirect(url_for("products"))

@app.route("/admin/appointment", methods=["GET", "POST"])
def appointment():
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    
    if request.method == "POST":
        apt_id = request.form.get("apt_id")
        status = request.form.get("status")
        if apt_id and status:
            cursor.execute("UPDATE appointment SET status = ? WHERE id = ?", (status, apt_id))
            conn.commit()
            flash(f"Appointment marked as {status}!", "success")
        else:
            cursor.execute("""
                INSERT INTO appointment (customer_id, service_id, date, time, status) 
                VALUES (?, ?, ?, ?, 'Accepted')
            """, (request.form.get("customer_id"), request.form.get("service_id"), request.form.get("date"), request.form.get("time")))
            conn.commit()
            flash("Offline Appointment reserved and Accepted!", "success")
        return redirect(url_for("appointment"))

    cursor.execute("SELECT * FROM customer")
    customers = [dict(row) for row in cursor.fetchall()]
    cursor.execute("SELECT * FROM service")
    services = [dict(row) for row in cursor.fetchall()]
    cursor.execute("""
        SELECT a.id, c.name as customer_name, s.service_name, a.date, a.time, a.status 
        FROM appointment a JOIN customer c ON a.customer_id = c.id JOIN service s ON a.service_id = s.id
        ORDER BY a.date DESC, a.time DESC
    """)
    appointments = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("appointment.html", customers=customers, services=services, appointments=appointments)

@app.route("/admin/billing", methods=["GET"])
def billing():
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM customer")
    customers = [dict(row) for row in cursor.fetchall()]
    cursor.execute("SELECT * FROM service")
    services = [dict(row) for row in cursor.fetchall()]
    cursor.execute("SELECT * FROM product WHERE stock > 0")
    products = [dict(row) for row in cursor.fetchall()]
    cursor.execute("SELECT b.id, c.name, b.total_amount, b.bill_date FROM bill b JOIN customer c ON b.customer_id = c.id ORDER BY b.id DESC")
    bills = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("billing.html", customers=customers, services=services, products=products, bills=bills)

@app.route("/admin/api/save_bill", methods=["POST"])
def save_bill():
    if not is_admin(): return jsonify({"success": False, "message": "Unauthorized"}), 401
    data = request.json
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO bill (customer_id, appointment_id, total_amount, bill_date) VALUES (?, ?, ?, date('now'))", 
                       (data["customer_id"], data.get("appointment_id"), data.get("total_amount", 0)))
        bill_id = cursor.lastrowid
        for item in data.get("items", []):
            cursor.execute("INSERT INTO bill_item (bill_id, item_name, item_type, quantity, price) VALUES (?, ?, ?, ?, ?)", 
                           (bill_id, item['name'], item['type'], item['qty'], item['price']))
            if item['type'] == 'Product':
                cursor.execute("UPDATE product SET stock = stock - ? WHERE id = ?", (item['qty'], item['id']))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "message": "Invoice generated successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route("/admin/api/customer_appointments/<int:customer_id>")
def customer_appointments(customer_id):
    if not is_admin(): return jsonify([]), 401
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.id, s.service_name, a.date, a.status 
        FROM appointment a JOIN service s ON a.service_id = s.id 
        WHERE a.customer_id = ? AND a.status IN ('Accepted', 'Completed')
        ORDER BY a.date DESC
    """, (customer_id,))
    apts = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify(apts)

@app.route("/admin/bill/<int:bill_id>")
def view_bill(bill_id):
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT b.*, c.name as customer_name, c.phone FROM bill b JOIN customer c ON b.customer_id = c.id WHERE b.id = ?", (bill_id,))
    bill = cursor.fetchone()
    if bill:
        bill = dict(bill)
    cursor.execute("SELECT * FROM bill_item WHERE bill_id = ?", (bill_id,))
    items = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("view_bill.html", bill=bill, items=items, is_user=False)

@app.route("/admin/feedback")
def admin_feedback():
    if not is_admin(): return redirect(url_for("admin_login"))
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT f.*, c.name, c.email 
        FROM feedback f 
        JOIN customer c ON f.customer_id = c.id 
        ORDER BY f.created_at DESC
    """)
    feedbacks = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return render_template("admin_feedback.html", feedbacks=feedbacks)

if __name__ == "__main__":
    app.run(debug=True, port=5000)